

  $('.close-btn').click(function(){
    $('.popup').removeClass('active');
  });
  
  $('.a').click(function(){
    $('.popup').removeClass('active');
    $('.a-p').addClass('active');
  });
  
  $('.b').click(function(){
    $('.popup').removeClass('active');
    $('.b-p').addClass('active');
  });
  
  $('.c').click(function(){
    $('.popup').removeClass('active');
    $('.c-p').addClass('active');
  });